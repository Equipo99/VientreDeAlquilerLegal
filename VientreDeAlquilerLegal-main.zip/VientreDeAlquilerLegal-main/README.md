# VientreDeAlquilerLegal
Se busca legalizar por medio de una ley que las personas puedan tener hijos a través del vientre de alquiler en México, asi como facilitar el acuerdo entre los interesados en el servicio.
